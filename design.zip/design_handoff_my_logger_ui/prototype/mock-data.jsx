/* mock-data.jsx — sample env, logs, ignore lists, dashboard rollup
   Exposed to window for cross-file use. */

const ENVS = ["prod-eu", "prod-us", "staging", "dev"];

const APPS = [
  "checkout-api", "payments-svc", "auth-gateway", "inventory-worker",
  "search-indexer", "mailer", "billing-jobs", "edge-proxy", "media-cdn",
  "user-importer", "fraud-detect", "feature-flags",
];

const PROCESSES = [
  "checkout-api/p-a17", "checkout-api/p-b02", "payments-svc/main",
  "auth-gateway/web-3", "inventory-worker/w-12", "search-indexer/idx-4",
  "mailer/queue", "edge-proxy/lb-7",
];

const LEVELS = ["Debug", "Info", "Warning", "Error", "FatalError"];
const lvlClass = (l) => ({
  Debug: "lvl-debug",
  Info: "lvl-info",
  Warning: "lvl-warning",
  Error: "lvl-error",
  FatalError: "lvl-fatal",
  All: "lvl-all",
}[l] || "lvl-debug");

// deterministic pseudo-random
let _seed = 42;
function rand() { _seed = (_seed * 9301 + 49297) % 233280; return _seed / 233280; }
const pick = (arr) => arr[Math.floor(rand() * arr.length)];
const choice = (...opts) => opts[Math.floor(rand() * opts.length)];

const MESSAGES = {
  Debug:    ["Fetched 12 keys from cache", "Connection pool size=18", "Heartbeat ok", "Trace sampled 1/64"],
  Info:     ["Request completed in 142ms", "Indexed 480 docs", "User session opened", "Job 'nightly-rollup' scheduled", "Cache warmed (3.4MB)"],
  Warning:  ["Slow query: 1.42s on items_by_user", "Retrying upstream auth (attempt 2/3)", "Disk usage at 81%", "Skipped malformed payload", "Cache miss rate above 30%"],
  Error:    ["Failed to enqueue job: timeout", "Database connection refused", "Unhandled rejection in handler 'capture'", "S3 PutObject 503 (after 3 retries)", "Payment provider returned 422", "Token validation failed for client 'svc-edge'"],
  FatalError:["Out of memory: worker killed", "Schema migration aborted: lock_timeout", "Cluster lost quorum, halting writes"],
};

const CTX_KEYS = {
  Application: APPS,
  Version: ["3.14.2", "3.14.1", "3.15.0-beta.4", "3.13.7"],
  RequestId: () => "req_" + Math.floor(rand()*1e10).toString(16).slice(0,10),
  UserId: () => "u_" + Math.floor(rand()*900000+100000),
  Region: ["eu-west-1", "eu-central-1", "us-east-1", "us-west-2"],
  TraceId: () => Math.floor(rand()*1e16).toString(16).padStart(16,"0"),
  TenantId: ["acme", "globex", "soylent", "initech", "stark"],
  HttpMethod: ["GET", "POST", "PUT", "DELETE"],
  StatusCode: ["200", "204", "400", "401", "404", "422", "500", "503"],
  Endpoint: ["/v1/orders", "/v1/payments/charge", "/v1/auth/token", "/v1/items/search", "/health"],
};

const CTX_KEY_NAMES = Object.keys(CTX_KEYS);

function genCtx(lvl) {
  const keys = ["Application", "Version", "RequestId", "Region"];
  if (rand() > 0.4) keys.push("TenantId");
  if (rand() > 0.5) keys.push("Endpoint");
  if (rand() > 0.6) keys.push("StatusCode");
  if (lvl === "Error" || lvl === "FatalError") keys.push("TraceId");
  if (rand() > 0.7) keys.push("UserId");
  return keys.map(k => {
    const src = CTX_KEYS[k];
    const v = typeof src === "function" ? src() : pick(src);
    return { k, v };
  });
}

function genLogs(n = 80) {
  _seed = 42;
  const now = new Date();
  const out = [];
  for (let i = 0; i < n; i++) {
    const lvlWeight = rand();
    let lvl;
    if (lvlWeight < 0.04) lvl = "FatalError";
    else if (lvlWeight < 0.32) lvl = "Error";
    else if (lvlWeight < 0.55) lvl = "Warning";
    else if (lvlWeight < 0.85) lvl = "Info";
    else lvl = "Debug";
    const offMs = i * (15_000 + Math.floor(rand()*60_000));
    const t = new Date(now.getTime() - offMs);
    out.push({
      id: i,
      lvl,
      t,
      proc: pick(PROCESSES),
      msg: pick(MESSAGES[lvl]),
      ctx: genCtx(lvl),
    });
  }
  return out;
}

const LOGS = genLogs(120);

// dashboard rollup: 24 hours back
function genHourly() {
  _seed = 9;
  const hours = [];
  const now = new Date();
  for (let h = 0; h < 24; h++) {
    const start = new Date(now); start.setHours(now.getHours() - h, 0, 0, 0);
    const apps = [];
    const appsToInclude = 2 + Math.floor(rand()*5);
    const shuffled = [...APPS].sort(() => rand() - 0.5).slice(0, appsToInclude);
    for (const a of shuffled) {
      const e = Math.floor(rand()*60);
      const f = rand() > 0.85 ? Math.floor(rand()*4)+1 : 0;
      const w = Math.floor(rand()*120);
      if (e === 0 && f === 0 && w === 0) continue;
      apps.push({ app: a, errors: e, fatal: f, warnings: w });
    }
    apps.sort((a,b) => (b.fatal*1000 + b.errors*10 + b.warnings) - (a.fatal*1000 + a.errors*10 + a.warnings));
    hours.push({ hour: start, apps });
  }
  return hours;
}
const HOURLY = genHourly();

// chart series: per-hour counts
function genChartSeries() {
  _seed = 21;
  const out = [];
  const now = new Date();
  for (let h = 23; h >= 0; h--) {
    const start = new Date(now); start.setHours(now.getHours() - h, 0, 0, 0);
    out.push({
      hour: start,
      Debug:   Math.floor(rand()*40),
      Info:    Math.floor(rand()*140 + 30),
      Warning: Math.floor(rand()*90 + 5),
      Error:   Math.floor(rand()*60),
      FatalError: rand() > 0.78 ? Math.floor(rand()*3+1) : 0,
    });
  }
  return out;
}
const CHART = genChartSeries();

// ignore list samples
const IGNORE_LIST = [
  { lvl: "Warning", app: "checkout-api", marker: "Slow query: 1.42s on items_by_user" },
  { lvl: "Warning", app: "*", marker: "Disk usage at 81%" },
  { lvl: "Error", app: "search-indexer", marker: "Cache miss rate above 30%" },
  { lvl: "Info", app: "*", marker: "User session opened" },
  { lvl: "Debug", app: "*", marker: "Heartbeat ok" },
];

const ONE_TIME = [
  {
    levels: ["Error", "FatalError"],
    msg: "Payment provider returned 422",
    ctx: [{ k: "TenantId", v: "acme" }, { k: "Endpoint", v: "/v1/payments/charge" }],
    skip: 5, minutes: 30,
  },
  {
    levels: ["Warning"],
    msg: "Retrying upstream auth (attempt 2/3)",
    ctx: [{ k: "Region", v: "eu-west-1" }],
    skip: 20, minutes: 15,
  },
  {
    levels: ["Error"],
    msg: "S3 PutObject 503",
    ctx: [],
    skip: 10, minutes: 60,
  },
];

// insights — list of known context keys for current env, with samples and counts
const INSIGHTS = [
  { k: "Application", sample: "checkout-api, payments-svc, …", count: 12 },
  { k: "Version", sample: "3.14.2, 3.14.1, 3.15.0-beta.4", count: 4 },
  { k: "RequestId", sample: "req_a17f3c19", count: 41028 },
  { k: "UserId", sample: "u_482910", count: 8821 },
  { k: "Region", sample: "eu-west-1, eu-central-1, …", count: 4 },
  { k: "TraceId", sample: "9a3e1f04…", count: 41028 },
  { k: "TenantId", sample: "acme, globex, …", count: 5 },
  { k: "HttpMethod", sample: "GET, POST, PUT, DELETE", count: 4 },
  { k: "StatusCode", sample: "200, 204, 400, 422, 500", count: 8 },
  { k: "Endpoint", sample: "/v1/orders, /v1/payments/charge, …", count: 24 },
];

Object.assign(window, {
  ENVS, APPS, LEVELS, lvlClass,
  LOGS, HOURLY, CHART, IGNORE_LIST, ONE_TIME, INSIGHTS,
  CTX_KEY_NAMES,
});
