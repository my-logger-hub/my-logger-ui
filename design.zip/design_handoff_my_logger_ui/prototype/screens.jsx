/* screens.jsx — Dashboard, Logs, IgnoreLists, Settings */

const { useState: sUseState, useEffect: sUseEffect, useRef: sUseRef, useMemo: sUseMemo } = React;

/* ============================================================
   DASHBOARD
   ============================================================ */
function Dashboard({ env, tz, openLogsFiltered }) {
  return (
    <div className="ml-page">
      <ChartCard env={env} tz={tz}/>
      <TopAppsCard tz={tz} openLogsFiltered={openLogsFiltered}/>
    </div>
  );
}

/* ---- Hourly chart (SVG, mimicking Google Charts grouped bars) ---- */
function ChartCard({ env, tz }) {
  const data = CHART;
  const maxStack = Math.max(...data.map(h => h.Debug + h.Info + h.Warning + h.Error + h.FatalError));
  // grouped bars — show stacked for compactness like Datadog
  const W = 1200, H = 320, padL = 38, padR = 12, padT = 12, padB = 28;
  const innerW = W - padL - padR, innerH = H - padT - padB;
  const groupW = innerW / data.length;
  const barW = Math.max(6, groupW * 0.62);

  const series = [
    { k: "FatalError", color: "var(--sev-fatal)" },
    { k: "Error",      color: "var(--sev-error)" },
    { k: "Warning",    color: "var(--sev-warning)" },
    { k: "Info",       color: "var(--sev-info)" },
    { k: "Debug",      color: "var(--sev-debug)" },
  ];

  return (
    <section className="ml-card">
      <header className="ml-card__hd">
        <div className="ml-card__title">Errors statistics per hour</div>
        <div className="ml-card__sub">
          Environment: <strong style={{color:"var(--ml-fg)"}}>{env}</strong> · Window: last 24h · {tz}
        </div>
      </header>

      <div className="ml-chart__legend">
        {series.map(s => (
          <span key={s.k}>
            <span className="sw" style={{ background: s.color }}/>{s.k}
          </span>
        ))}
        <span style={{marginLeft:"auto", color:"var(--ml-fg-mute)", fontFamily:"var(--ml-font-mono)"}}>
          peak {maxStack}/h
        </span>
      </div>

      <div className="ml-chart" style={{ height: 360 }}>
        <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
          {/* y gridlines */}
          {[0, 0.25, 0.5, 0.75, 1].map((g,i) => {
            const y = padT + innerH * (1 - g);
            const v = Math.round(maxStack * g);
            return (
              <g key={i}>
                <line x1={padL} x2={W - padR} y1={y} y2={y} stroke="var(--ml-border-soft)" strokeDasharray={g===0?"":"2 3"}/>
                <text x={padL - 6} y={y+3} textAnchor="end" fontSize="10"
                      fill="var(--ml-fg-mute)" fontFamily="var(--ml-font-mono)">{v}</text>
              </g>
            );
          })}

          {data.map((h, i) => {
            const xCenter = padL + groupW * i + groupW / 2;
            let yCursor = padT + innerH;
            return (
              <g key={i}>
                {series.map(s => {
                  const v = h[s.k];
                  if (!v) return null;
                  const barH = Math.round((v / maxStack) * innerH);
                  yCursor -= barH;
                  return (
                    <rect key={s.k}
                          x={xCenter - barW/2}
                          y={yCursor}
                          width={barW}
                          height={barH}
                          fill={s.color}/>
                  );
                })}
                {/* x label every 3 hours */}
                {(i % 3 === 0 || i === data.length - 1) && (
                  <text x={xCenter} y={H - padB + 14} textAnchor="middle"
                        fontSize="10" fill="var(--ml-fg-mute)" fontFamily="var(--ml-font-mono)">
                    {String(h.hour.getUTCHours()).padStart(2,"0")}:00
                  </text>
                )}
              </g>
            );
          })}
          {/* baseline */}
          <line x1={padL} x2={W-padR} y1={padT+innerH} y2={padT+innerH} stroke="var(--ml-border-strong)"/>
        </svg>
      </div>
    </section>
  );
}

/* ---- Top apps with errors ---- */
function TopAppsCard({ tz, openLogsFiltered }) {
  const max = Math.max(
    1,
    ...HOURLY.flatMap(h => h.apps.flatMap(a => [a.errors, a.fatal*4, a.warnings]))
  );
  return (
    <section className="ml-card">
      <header className="ml-card__hd">
        <div className="ml-card__title">Top apps with errors</div>
        <div className="ml-card__sub">grouped by hour, sorted by severity · counts deep-link to filtered Logs</div>
      </header>
      <div style={{maxHeight: 520, overflow:"auto"}}>
        <table className="ml-table">
          <thead>
            <tr>
              <th style={{paddingLeft:14}}>Application</th>
              <th style={{textAlign:"right", paddingRight:14}}>Errors</th>
              <th style={{textAlign:"right", paddingRight:14}}>Fatal errors</th>
              <th style={{textAlign:"right", paddingRight:14}}>Warnings</th>
            </tr>
          </thead>
          {HOURLY.map((h, hi) => (
              <tbody key={hi}>
                <tr className="ml-table__group">
                  <td colSpan={4} style={{paddingLeft:14}}>
                    <span style={{color:"var(--ml-fg-mute)", marginRight:8}}>
                      <Icon name="clock" size={11} style={{verticalAlign:-1, marginRight:5}}/>
                      Hour
                    </span>
                    {fmtHour(h.hour, tz)}
                    <span style={{marginLeft:10, color:"var(--ml-fg-faint)", fontWeight:500, fontSize:11}}>
                      {h.apps.length} apps · {h.apps.reduce((s,a)=>s+a.errors+a.fatal+a.warnings,0)} events
                    </span>
                  </td>
                </tr>
                {h.apps.length === 0 && (
                  <tr><td colSpan={4} style={{paddingLeft:14, color:"var(--ml-fg-mute)"}}>No errors this hour.</td></tr>
                )}
                {h.apps.map((a, ai) => (
                  <tr key={ai}>
                    <td style={{paddingLeft:14}} className="mono">{a.app}</td>
                    <td style={{paddingRight:14}}>
                      <BarCell value={a.errors} max={max} kind="lvl-error"
                               onClick={()=>openLogsFiltered({ app:a.app, level:"Error", hour:h.hour })}/>
                    </td>
                    <td style={{paddingRight:14}}>
                      <BarCell value={a.fatal} max={max/4} kind="lvl-fatal"
                               onClick={()=>openLogsFiltered({ app:a.app, level:"FatalError", hour:h.hour })}/>
                    </td>
                    <td style={{paddingRight:14}}>
                      <BarCell value={a.warnings} max={max} kind="lvl-warning"
                               onClick={()=>openLogsFiltered({ app:a.app, level:"Warning", hour:h.hour })}/>
                    </td>
                  </tr>
                ))}
              </tbody>
            ))}
        </table>
      </div>
    </section>
  );
}

/* ============================================================
   LOGS
   ============================================================ */
function LogsScreen({ tz, openTimeRange, timeLabel, deepLink }) {
  const [level, setLevel] = sUseState(deepLink?.level || "All");
  const [searchType, setSearchType] = sUseState(deepLink?.searchType || "Ctx Search");
  const [query, setQuery] = sUseState(deepLink?.query || "");
  const [insightsOpen, setInsightsOpen] = sUseState(false);
  const [insightsFilter, setInsightsFilter] = sUseState("");
  const [insightsIdx, setInsightsIdx] = sUseState(0);
  const inputRef = sUseRef(null);

  // sync deep-link
  sUseEffect(() => {
    if (deepLink) {
      if (deepLink.level !== undefined) setLevel(deepLink.level);
      if (deepLink.searchType) setSearchType(deepLink.searchType);
      if (deepLink.query !== undefined) setQuery(deepLink.query);
    }
  }, [deepLink]);

  // filter logs
  const filtered = sUseMemo(() => {
    let rows = LOGS;
    if (level !== "All") {
      rows = rows.filter(r => r.lvl === level || (level === "Error" && r.lvl === "FatalError"));
    }
    if (query.trim()) {
      if (searchType === "Text Search") {
        const q = query.toLowerCase();
        rows = rows.filter(r => r.msg.toLowerCase().includes(q));
      } else {
        // ctx-style: try to parse Application='X' patterns
        const tokens = [...query.matchAll(/([A-Za-z]+)\s*[:=]\s*'?([^']+?)'?(?=\s+and\s+|\s*$)/gi)];
        if (tokens.length) {
          rows = rows.filter(r =>
            tokens.every(([_, k, v]) =>
              r.ctx.some(p => p.k.toLowerCase() === k.toLowerCase() && p.v.toLowerCase().includes(v.toLowerCase()))
              || (k.toLowerCase() === "process" && r.proc.toLowerCase().includes(v.toLowerCase()))
            )
          );
        }
      }
    }
    return rows;
  }, [level, query, searchType]);

  const appendCtxFilter = (key, val) => {
    const t = `${key}:'${val}'`;
    setQuery(q => q.trim() ? `${q} and ${t}` : t);
  };
  const appendProcFilter = (proc) => appendCtxFilter("Process", proc);

  // insights filter
  const insightsList = sUseMemo(() => {
    const f = insightsFilter.toLowerCase().trim();
    return INSIGHTS.filter(i => !f || i.k.toLowerCase().includes(f));
  }, [insightsFilter]);

  const onSearchKey = (e) => {
    if (searchType === "Ctx Search" && (e.key === "@" || (e.ctrlKey && e.key === " "))) {
      setInsightsOpen(true);
      setInsightsFilter("");
      setInsightsIdx(0);
      e.preventDefault();
      return;
    }
    if (insightsOpen) {
      if (e.key === "Escape") { setInsightsOpen(false); e.preventDefault(); return; }
      if (e.key === "ArrowDown") { setInsightsIdx(i => Math.min(i+1, insightsList.length-1)); e.preventDefault(); return; }
      if (e.key === "ArrowUp") { setInsightsIdx(i => Math.max(0, i-1)); e.preventDefault(); return; }
      if (e.key === "Enter" || e.key === "Tab") {
        const item = insightsList[insightsIdx];
        if (item) {
          setQuery(q => (q.trim() ? q + " and " : "") + item.k + ":'");
          setInsightsOpen(false);
          e.preventDefault();
          return;
        }
      }
    }
    if (e.key === "Enter") {
      // trigger search
      inputRef.current?.blur();
    }
  };

  const placeholder = searchType === "Ctx Search"
    ? "Application='MyApp' and Version='3.14.2'"
    : "Just a text";

  const ctxMode = searchType === "Ctx Search";

  return (
    <div className="ml-page--logs" style={{display:"flex", flexDirection:"column"}}>
      {/* SEARCH BAR */}
      <div className="ml-logbar">
        <div className="ml-logbar__group">
          <span className="ml-field__label">Level</span>
          <select
            className={`ml-select ml-select--lvl ${lvlClass(level)}`}
            value={level} onChange={e=>setLevel(e.target.value)} style={{width: 110}}>
            <option value="All">All</option>
            {LEVELS.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>

        <div className="ml-logbar__group">
          <span className="ml-field__label">Time</span>
          <button className="ml-btn" onClick={openTimeRange} style={{minWidth:160, justifyContent:"flex-start"}}>
            <Icon name="clock"/> <span style={{fontFamily:"var(--ml-font-mono)", fontSize:12}}>{timeLabel}</span>
          </button>
        </div>

        <div className="ml-logbar__group">
          <span className="ml-field__label">Type</span>
          <select className="ml-select" value={searchType} onChange={e=>setSearchType(e.target.value)} style={{width:120}}>
            <option>Ctx Search</option>
            <option>Text Search</option>
          </select>
        </div>

        <div className="ml-logbar__search" onBlur={(e) => {
          if (!e.currentTarget.contains(e.relatedTarget)) setInsightsOpen(false);
        }}>
          <span className="ico"><Icon name="search"/></span>
          <input
            ref={inputRef}
            className="ml-input"
            placeholder={placeholder}
            value={query}
            onChange={e=>{ setQuery(e.target.value); if (ctxMode) setInsightsFilter(e.target.value.split(/\s+and\s+/i).pop()||""); }}
            onFocus={()=>{ if (ctxMode && (!query || query.endsWith(" "))) setInsightsOpen(true); }}
            onKeyDown={onSearchKey}
          />
          <span className="ml-logbar__searchhint">{ctxMode ? "@ for fields" : "↵ search"}</span>
          {insightsOpen && ctxMode && (
            <div className="ml-insights" onMouseDown={e=>e.preventDefault()}>
              <div className="ml-insights__hd">
                <Icon name="filter" size={11}/> Context keys for this env
                <span style={{marginLeft:"auto"}}>{insightsList.length} of {INSIGHTS.length}</span>
              </div>
              <div className="ml-insights__list">
                {insightsList.length === 0 && (
                  <div className="ml-insights__item" style={{cursor:"default", color:"var(--ml-fg-mute)"}}>
                    No matching keys.
                  </div>
                )}
                {insightsList.map((it, i) => (
                  <div key={it.k}
                       className={`ml-insights__item ${i===insightsIdx?"is-active":""}`}
                       onMouseEnter={()=>setInsightsIdx(i)}
                       onClick={()=>{
                         setQuery(q => (q.trim() ? q + " and " : "") + it.k + ":'");
                         setInsightsOpen(false);
                         inputRef.current?.focus();
                       }}>
                    <span className="ml-insights__k">{it.k}</span>
                    <span className="ml-insights__sample">{it.sample}</span>
                    <span className="ml-insights__count">{it.count.toLocaleString()}</span>
                  </div>
                ))}
              </div>
              <div className="ml-insights__ft">
                <span><span className="ml-insights__kbd">↑↓</span> navigate · <span className="ml-insights__kbd">↵</span> insert · <span className="ml-insights__kbd">esc</span> close</span>
                <span>{ctxMode ? "Ctx Search mode" : ""}</span>
              </div>
            </div>
          )}
        </div>

        <button className="ml-btn ml-btn--icon" title="Refresh / shareable link">
          <Icon name="refresh"/>
        </button>
        <button className="ml-btn ml-btn--icon" title="Copy deep link">
          <Icon name="share"/>
        </button>
      </div>

      {/* RESULTS */}
      <div style={{padding: "0 14px 60px"}}>
        <div className="ml-hint" style={{padding:"8px 2px", display:"flex", alignItems:"center", gap:10}}>
          <span><strong style={{color:"var(--ml-fg)"}}>{filtered.length.toLocaleString()}</strong> events</span>
          <span>·</span>
          <span>{timeLabel}</span>
          {ctxMode && (
            <>
              <span>·</span>
              <span>Click any context key, value or process to add as filter.</span>
            </>
          )}
          <span style={{marginLeft:"auto"}}><span className="ml-spinner" style={{display:"none"}}/></span>
        </div>

        <div className="ml-card ml-card--flat">
          <div style={{maxHeight: "calc(100vh - 160px)", overflow:"auto"}}>
            <table className={`ml-table ml-table--logs ${ctxMode ? "is-clickable" : ""}`}>
              <thead>
                <tr>
                  <th className="col--ball"></th>
                  <th className="col--time">Time</th>
                  <th className="col--proc">Process</th>
                  <th>Message</th>
                  <th>Context</th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 && (
                  <tr><td colSpan={5}>
                    <EmptyState title="No matching events"
                      sub="Try a wider time range, different level, or remove search terms."
                      icon="search"/>
                  </td></tr>
                )}
                {filtered.map(r => (
                  <tr key={r.id}>
                    <td className="col--ball"><Ball lvl={r.lvl}/></td>
                    <td className="col--time">{fmtTime(r.t, tz)}</td>
                    <td className="col--proc" onClick={ctxMode ? () => appendProcFilter(r.proc) : null}>
                      {r.proc}
                    </td>
                    <td className="col--msg">{r.msg}</td>
                    <td>
                      <KVList items={r.ctx} clickable={ctxMode}
                              onClickPair={(p) => appendCtxFilter(p.k, p.v)}/>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   IGNORE LISTS
   ============================================================ */
function IgnoreLists({ subtab, setSubtab, openAdd, openEdit, openDelete }) {
  const [list, setList] = sUseState(IGNORE_LIST);
  const [one, setOne] = sUseState(ONE_TIME);

  return (
    <div className="ml-page">
      <div className="ml-tabs">
        <div className={`ml-tabs__tab ${subtab==="standing"?"is-active":""}`} onClick={()=>setSubtab("standing")}>
          Ignore list <span className="count">{list.length}</span>
        </div>
        <div className={`ml-tabs__tab ${subtab==="onetime"?"is-active":""}`} onClick={()=>setSubtab("onetime")}>
          One time ignore <span className="count">{one.length}</span>
        </div>
      </div>

      {subtab === "standing" && (
        <section className="ml-card ml-card--flat">
          <header className="ml-card__hd">
            <div className="ml-card__title">Standing ignore rules</div>
            <div className="ml-card__sub">Permanent filters applied to all incoming events.</div>
            <button className="ml-btn is-primary" style={{marginLeft:12}}
                    onClick={()=>openAdd((event) => setList([...list, event]))}>
              <Icon name="plus"/> Add ignore event
            </button>
          </header>
          <table className="ml-table">
            <thead>
              <tr>
                <th className="col--ball"></th>
                <th className="col--lvl">Level</th>
                <th className="col--app">Application</th>
                <th>Marker</th>
                <th className="col--actions">Actions</th>
              </tr>
            </thead>
            <tbody>
              {list.length === 0 && (
                <tr><td colSpan={5}><EmptyState title="No standing rules" sub="Add an ignore rule to silence recurring noise from the dashboard." icon="ignore"/></td></tr>
              )}
              {list.map((r, i) => (
                <tr key={i}>
                  <td className="col--ball"><Ball lvl={r.lvl}/></td>
                  <td><LvlTag lvl={r.lvl}/></td>
                  <td className="mono">{r.app}</td>
                  <td className="mono" style={{color:"var(--ml-fg-2)"}}>{r.marker}</td>
                  <td className="col--actions">
                    <button className="ml-btn is-ghost" title="Edit">
                      <Icon name="pencil"/>
                    </button>
                    <button className="ml-btn is-ghost" title="Delete"
                            onClick={()=>openDelete({
                              title: "Delete ignore rule?",
                              body: <>Stop ignoring <strong>{r.marker}</strong> on <strong>{r.app}</strong>. The rule will be removed immediately.</>,
                              onConfirm: () => setList(list.filter((_,idx)=>idx!==i)),
                            })}>
                      <Icon name="trash"/>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}

      {subtab === "onetime" && (
        <section className="ml-card ml-card--flat">
          <header className="ml-card__hd">
            <div className="ml-card__title">One-time ignore rules</div>
            <div className="ml-card__sub">Temporary suppression — auto-expire after N minutes or M skips.</div>
            <button className="ml-btn is-primary" style={{marginLeft:12}}
                    onClick={()=>openEdit(null, (saved) => setOne([...one, saved]))}>
              <Icon name="plus"/> Add one-time ignore
            </button>
          </header>
          <table className="ml-table">
            <thead>
              <tr>
                <th>Levels</th>
                <th>Message match</th>
                <th>Context match</th>
                <th className="col--num">Skip</th>
                <th className="col--num">Minutes</th>
                <th className="col--actions">Actions</th>
              </tr>
            </thead>
            <tbody>
              {one.length === 0 && (
                <tr><td colSpan={6}><EmptyState title="No one-time rules" sub="Use these during an incident to mute a known issue temporarily." icon="clock"/></td></tr>
              )}
              {one.map((r, i) => (
                <tr key={i}>
                  <td>
                    <div className="ml-form__inline">
                      {r.levels.map(l => (
                        <span key={l} className={`ml-lvltag ${lvlClass(l)}`} style={{padding:"1px 6px"}}>
                          <Ball lvl={l} size={5}/> {l}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="mono">{r.msg}</td>
                  <td>{r.ctx.length === 0 ? <span style={{color:"var(--ml-fg-faint)"}}>—</span> : <KVList items={r.ctx}/>}</td>
                  <td className="col--num mono">{r.skip}</td>
                  <td className="col--num mono">{r.minutes}</td>
                  <td className="col--actions">
                    <button className="ml-btn is-ghost" title="Edit"
                            onClick={()=>openEdit(r, (saved) => setOne(one.map((x,idx)=>idx===i?saved:x)))}>
                      <Icon name="pencil"/>
                    </button>
                    <button className="ml-btn is-ghost" title="Delete"
                            onClick={()=>openDelete({
                              title: "Delete one-time rule?",
                              body: <>Remove suppression of <strong>{r.msg}</strong>. Future matching events will fire again.</>,
                              onConfirm: () => setOne(one.filter((_,idx)=>idx!==i)),
                            })}>
                      <Icon name="trash"/>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}
    </div>
  );
}

/* ============================================================
   SETTINGS
   ============================================================ */
function Settings({ tz, setTz, dark, setDark }) {
  return (
    <div className="ml-page">
      <section className="ml-card ml-settings">
        <header className="ml-card__hd">
          <div className="ml-card__title">Settings</div>
          <div className="ml-card__sub">Local to this browser — persisted in localStorage.</div>
        </header>
        <div className="ml-card__bd">
          <div className="ml-settings__row">
            <div className="ml-settings__lbl">
              <strong>Time zone</strong>
              <span>Drives every timestamp rendered in the app.</span>
            </div>
            <div>
              <select className="ml-select" value={tz} onChange={e=>setTz(e.target.value)} style={{width:200}}>
                <option value="UTC+0">UTC+0</option>
                <option value="Local">Local Time ({Intl.DateTimeFormat().resolvedOptions().timeZone})</option>
              </select>
            </div>
          </div>
          <div className="ml-settings__row">
            <div className="ml-settings__lbl">
              <strong>Theme</strong>
              <span>Light or dark UI. Severity colors retain their meaning in both.</span>
            </div>
            <div className="ml-seg">
              <button className={`ml-seg__btn ${!dark?"is-active":""}`} onClick={()=>setDark(false)}>
                <Icon name="sun" size={12} style={{marginRight:6, verticalAlign:-2}}/>Light
              </button>
              <button className={`ml-seg__btn ${dark?"is-active":""}`} onClick={()=>setDark(true)}>
                <Icon name="moon" size={12} style={{marginRight:6, verticalAlign:-2}}/>Dark
              </button>
            </div>
          </div>
          <div className="ml-settings__row">
            <div className="ml-settings__lbl">
              <strong>Density</strong>
              <span>Affects table row height and form spacing. (Demo — adjusts CSS vars.)</span>
            </div>
            <div className="ml-seg">
              <button className="ml-seg__btn is-active">Dense</button>
              <button className="ml-seg__btn">Compact</button>
              <button className="ml-seg__btn">Comfortable</button>
            </div>
          </div>
          <div className="ml-settings__row">
            <div className="ml-settings__lbl">
              <strong>Auto-refresh</strong>
              <span>Periodically re-poll while Logs or Dashboard are open.</span>
            </div>
            <div className="ml-input-row">
              <select className="ml-select" style={{width:120}} defaultValue="off">
                <option value="off">Off</option>
                <option value="15s">Every 15s</option>
                <option value="1m">Every 1m</option>
                <option value="5m">Every 5m</option>
              </select>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

Object.assign(window, { Dashboard, LogsScreen, IgnoreLists, Settings });
