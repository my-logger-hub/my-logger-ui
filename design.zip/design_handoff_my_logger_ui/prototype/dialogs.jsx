/* dialogs.jsx — modal shell + the four product dialogs */

const { useState: dUseState, useEffect: dUseEffect, useMemo: dUseMemo } = React;

/* ---------- Modal shell ---------- */
function Modal({ title, onClose, footer, children, wide }) {
  dUseEffect(() => {
    const k = (e) => { if (e.key === "Escape") onClose?.(); };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <div className="ml-modal-pad" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose?.(); }}>
      <div className={`ml-modal ${wide ? "ml-modal--wide" : ""}`} role="dialog" aria-modal="true">
        <div className="ml-modal__hd">
          <Icon name="dot" size={4} style={{display:"none"}}/>
          <div className="ml-modal__title">{title}</div>
          <button className="ml-modal__close" onClick={onClose} aria-label="Close">
            <Icon name="x" size={12}/>
          </button>
        </div>
        <div className="ml-modal__bd">{children}</div>
        {footer && <div className="ml-modal__ft">{footer}</div>}
      </div>
    </div>
  );
}

/* ---------- Time Range dialog ---------- */
function TimeRangeDialog({ initial, onClose, onApply }) {
  const [mode, setMode] = dUseState(initial?.mode || "hours");
  const [hours, setHours] = dUseState(initial?.hours ?? 6);
  const [from, setFrom] = dUseState(initial?.from || isoLocal(new Date(Date.now()-6*3600_000)));
  const [to, setTo] = dUseState(initial?.to || isoLocal(new Date()));
  const [exact, setExact] = dUseState(initial?.exact || isoLocal(new Date()));

  const apply = () => {
    if (mode === "hours") onApply({ mode, hours, label: `Last ${hours}h`});
    if (mode === "range") onApply({ mode, from, to, label: `${from.slice(5,16)} → ${to.slice(5,16)}`});
    if (mode === "exact") onApply({ mode, exact, label: `Hour ${exact.slice(5,16)}`});
  };

  return (
    <Modal title="Edit time range" onClose={onClose}
      footer={<>
        <button className="ml-btn" onClick={onClose}>Cancel</button>
        <button className="ml-btn is-primary" onClick={apply}>Apply</button>
      </>}>
      <div className="ml-form">
        <div className="ml-form__row">
          <label>Mode</label>
          <div className="ml-seg">
            <button className={`ml-seg__btn ${mode==="hours"?"is-active":""}`} onClick={()=>setMode("hours")}>Hours ago</button>
            <button className={`ml-seg__btn ${mode==="range"?"is-active":""}`} onClick={()=>setMode("range")}>Date range</button>
            <button className={`ml-seg__btn ${mode==="exact"?"is-active":""}`} onClick={()=>setMode("exact")}>Exact hour</button>
          </div>
        </div>

        {mode === "hours" && (
          <div className="ml-form__row">
            <label htmlFor="d-hours">Last</label>
            <div className="ml-input-row">
              <input id="d-hours" type="number" min="1" max="720"
                className="ml-input" style={{width:90}}
                value={hours} onChange={e=>setHours(Number(e.target.value))}/>
              <span className="ml-hint">hours back from now</span>
            </div>
          </div>
        )}

        {mode === "range" && (
          <>
            <div className="ml-form__row">
              <label htmlFor="d-from">From</label>
              <input id="d-from" type="datetime-local" className="ml-input"
                     value={from} onChange={e=>setFrom(e.target.value)}/>
            </div>
            <div className="ml-form__row">
              <label htmlFor="d-to">To</label>
              <input id="d-to" type="datetime-local" className="ml-input"
                     value={to} onChange={e=>setTo(e.target.value)}/>
            </div>
            <div className="ml-form__row">
              <span/>
              <span className="ml-hint">Timezone follows your Settings choice.</span>
            </div>
          </>
        )}

        {mode === "exact" && (
          <div className="ml-form__row">
            <label htmlFor="d-exact">Hour</label>
            <input id="d-exact" type="datetime-local" className="ml-input"
                   value={exact} onChange={e=>setExact(e.target.value)}/>
          </div>
        )}
      </div>
    </Modal>
  );
}
function isoLocal(d) {
  const pad = n => String(n).padStart(2,"0");
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:00`;
}

/* ---------- Add Ignore Event dialog ---------- */
function AddIgnoreDialog({ event, onClose, onConfirm }) {
  // two-step: edit → confirm
  const [step, setStep] = dUseState("edit");
  const [lvl, setLvl] = dUseState(event?.lvl || "Warning");
  const [app, setApp] = dUseState(event?.app || "");
  const [marker, setMarker] = dUseState(event?.marker || "");

  const valid = marker.trim().length > 0;

  if (step === "confirm") {
    return (
      <Modal title="Confirm: add to ignore list" onClose={onClose}
        footer={<>
          <button className="ml-btn" onClick={()=>setStep("edit")}>Back</button>
          <button className="ml-btn is-primary" onClick={()=>onConfirm({lvl, app: app || "*", marker})}>Add to ignore list</button>
        </>}>
        <div className="ml-modal__warn">
          <Icon name="warn"/>
          <div>
            Future events matching this pattern will be hidden from the dashboard
            and dropped from search results. You can remove the entry from the
            <strong> Ignore list</strong> tab at any time.
          </div>
        </div>
        <div className="ml-form">
          <div className="ml-form__row"><label>Level</label><div><LvlTag lvl={lvl}/></div></div>
          <div className="ml-form__row"><label>Application</label>
            <code className="ml-pill mono">{app || "*"}</code></div>
          <div className="ml-form__row ml-form__row--top"><label>Marker</label>
            <div className="mono" style={{fontSize:12, padding:8, background:"var(--ml-bg-sub)", borderRadius:4, border:"1px solid var(--ml-border)"}}>
              {marker}
            </div>
          </div>
        </div>
      </Modal>
    );
  }
  return (
    <Modal title={event ? "Edit ignore event" : "Add ignore event"} onClose={onClose}
      footer={<>
        <button className="ml-btn" onClick={onClose}>Cancel</button>
        <button className={`ml-btn is-primary ${valid?"":"is-disabled"}`} onClick={()=>valid && setStep("confirm")}>Next</button>
      </>}>
      <div className="ml-form">
        <div className="ml-form__row">
          <label>Level</label>
          <select className={`ml-select ml-select--lvl ${lvlClass(lvl)}`} value={lvl} onChange={e=>setLvl(e.target.value)}>
            {LEVELS.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
        <div className="ml-form__row">
          <label htmlFor="i-app">Application</label>
          <input id="i-app" className="ml-input ml-input--mono" placeholder="* (all apps)"
                 value={app} onChange={e=>setApp(e.target.value)}/>
        </div>
        <div className="ml-form__row ml-form__row--top">
          <label htmlFor="i-marker">Marker</label>
          <div className="ml-field" style={{minWidth:0}}>
            <textarea id="i-marker" className={`ml-input ml-input--mono ${marker.trim()===""?"is-invalid":""}`}
                      rows={3} style={{height:"auto", padding:6, resize:"vertical"}}
                      placeholder="Exact string to match in log message"
                      value={marker} onChange={e=>setMarker(e.target.value)}/>
            {!valid && <span className="ml-field__error">Marker is required.</span>}
            <span className="ml-field__hint">Matches as a substring of the log message.</span>
          </div>
        </div>
      </div>
    </Modal>
  );
}

/* ---------- Edit One-Time Ignore dialog ---------- */
function EditOneTimeDialog({ item, onClose, onSave }) {
  const [levels, setLevels] = dUseState(item?.levels || []);
  const [msg, setMsg] = dUseState(item?.msg || "");
  const [skip, setSkip] = dUseState(item?.skip ?? 1);
  const [minutes, setMinutes] = dUseState(item?.minutes ?? 15);
  const [ctx, setCtx] = dUseState(item?.ctx || []);
  const [k, setK] = dUseState("");
  const [v, setV] = dUseState("");

  const errMsg     = msg.trim() === "" ? "Message match is required." : "";
  const errLevels  = levels.length === 0 ? "Select at least one level." : "";
  const errSkip    = !(skip > 0) ? "Skip amount must be > 0." : "";
  const errMinutes = !(minutes > 0) ? "Minutes must be > 0." : "";
  const valid = !errMsg && !errLevels && !errSkip && !errMinutes;

  const toggleLvl = (l) => {
    setLevels(levels.includes(l) ? levels.filter(x => x !== l) : [...levels, l]);
  };
  const addCtx = () => {
    if (!k.trim() || !v.trim()) return;
    setCtx([...ctx, { k: k.trim(), v: v.trim() }]);
    setK(""); setV("");
  };
  const rmCtx = (i) => setCtx(ctx.filter((_,idx) => idx !== i));

  return (
    <Modal wide title={item ? "Edit one-time ignore" : "Add one-time ignore"} onClose={onClose}
      footer={<>
        <button className="ml-btn" onClick={onClose}>Cancel</button>
        <button className={`ml-btn is-primary ${valid?"":"is-disabled"}`}
                onClick={() => valid && onSave({levels, msg, skip, minutes, ctx})}>
          {item ? "Save changes" : "Add ignore"}
        </button>
      </>}>
      <div className="ml-form">
        <div className="ml-form__row ml-form__row--top">
          <label>Levels</label>
          <div className="ml-field" style={{minWidth:0}}>
            <div className="ml-form__inline">
              {LEVELS.map(l => (
                <label key={l} className={`ml-lvlchk ${levels.includes(l)?"is-checked":""}`}>
                  <input type="checkbox" checked={levels.includes(l)} onChange={()=>toggleLvl(l)} style={{display:"none"}}/>
                  <Ball lvl={l}/> {l}
                </label>
              ))}
            </div>
            {errLevels && <span className="ml-field__error">{errLevels}</span>}
          </div>
        </div>

        <div className="ml-form__row ml-form__row--top">
          <label htmlFor="o-msg">Message match</label>
          <div className="ml-field" style={{minWidth:0}}>
            <input id="o-msg" className={`ml-input ml-input--mono ${errMsg?"is-invalid":""}`}
                   placeholder="Substring of log message"
                   value={msg} onChange={e=>setMsg(e.target.value)}/>
            {errMsg ? <span className="ml-field__error">{errMsg}</span>
                    : <span className="ml-field__hint">Matches as a substring.</span>}
          </div>
        </div>

        <div className="ml-form__row">
          <label htmlFor="o-skip">Skip amount</label>
          <div className="ml-input-row">
            <input id="o-skip" type="number" min={1} className={`ml-input ${errSkip?"is-invalid":""}`}
                   style={{width:96}} value={skip} onChange={e=>setSkip(Number(e.target.value))}/>
            <span className="ml-hint">events to drop before alerting again</span>
          </div>
        </div>
        <div className="ml-form__row">
          <label htmlFor="o-min">Minutes to wait</label>
          <div className="ml-input-row">
            <input id="o-min" type="number" min={1} className={`ml-input ${errMinutes?"is-invalid":""}`}
                   style={{width:96}} value={minutes} onChange={e=>setMinutes(Number(e.target.value))}/>
            <span className="ml-hint">window before the rule expires</span>
          </div>
        </div>

        <div className="ml-form__row ml-form__row--top">
          <label>Context match</label>
          <div className="ml-kvedit">
            {ctx.length > 0 && (
              <div className="ml-form__inline">
                {ctx.map((p,i) => (
                  <span key={i} className="ml-kvedit__chip">
                    <span style={{color:"var(--ml-fg-mute)"}}>{p.k}</span>
                    <span style={{color:"var(--ml-fg-faint)"}}>=</span>
                    <span>{p.v}</span>
                    <button onClick={()=>rmCtx(i)} aria-label="remove">
                      <Icon name="x" size={10}/>
                    </button>
                  </span>
                ))}
              </div>
            )}
            <div className="ml-kvedit__add">
              <input list="ctxkeys" className="ml-input ml-input--mono" placeholder="Key"
                     value={k} onChange={e=>setK(e.target.value)}/>
              <input className="ml-input ml-input--mono" placeholder="Value"
                     value={v} onChange={e=>setV(e.target.value)}
                     onKeyDown={e=>{if(e.key==="Enter") addCtx();}}/>
              <button className="ml-btn" onClick={addCtx} disabled={!k.trim()||!v.trim()}>
                <Icon name="plus"/> Add
              </button>
              <datalist id="ctxkeys">
                {CTX_KEY_NAMES.map(n => <option key={n} value={n}/>)}
              </datalist>
            </div>
            <span className="ml-field__hint">All key/value pairs must match for the rule to fire.</span>
          </div>
        </div>
      </div>
    </Modal>
  );
}

/* ---------- Confirm dialog ---------- */
function ConfirmDialog({ title, body, danger, onClose, onConfirm, confirmLabel = "Delete" }) {
  return (
    <Modal title={title} onClose={onClose}
      footer={<>
        <button className="ml-btn" onClick={onClose}>Cancel</button>
        <button className={`ml-btn ${danger?"is-danger":"is-primary"}`} onClick={onConfirm}>
          {confirmLabel}
        </button>
      </>}>
      <div className="ml-modal__warn">
        <Icon name="warn"/>
        <div>{body}</div>
      </div>
    </Modal>
  );
}

Object.assign(window, {
  Modal, TimeRangeDialog, AddIgnoreDialog, EditOneTimeDialog, ConfirmDialog,
});
