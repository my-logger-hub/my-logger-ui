/* app.jsx — root, route state, dialog state, Tweaks */

const { useState: aUseState, useEffect: aUseEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "dark": false
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const [env, setEnv] = aUseState(() => localStorage.getItem("env") || "prod-eu");
  const [route, setRoute] = aUseState("dashboard");
  const [subtab, setSubtab] = aUseState("standing");
  const [tz, setTz] = aUseState(() => localStorage.getItem("tz") || "UTC+0");
  const [timeRange, setTimeRange] = aUseState({ mode: "hours", hours: 6, label: "Last 6h" });
  const [deepLink, setDeepLink] = aUseState(null);

  // dialogs
  const [showTimeDlg, setShowTimeDlg] = aUseState(false);
  const [addDlg, setAddDlg] = aUseState(null);          // {onAdd}
  const [editDlg, setEditDlg] = aUseState(null);        // {item,onSave}
  const [confirmDlg, setConfirmDlg] = aUseState(null);  // {title,body,onConfirm}

  // persist
  aUseEffect(() => { localStorage.setItem("env", env); }, [env]);
  aUseEffect(() => { localStorage.setItem("tz", tz); }, [tz]);

  // theme
  aUseEffect(() => {
    document.documentElement.setAttribute("data-theme", t.dark ? "dark" : "light");
  }, [t.dark]);

  const server = { client: "1.4.2", server: "1.4.2", gc: "1d 4h" };

  const goToLogs = () => {
    setRoute("logs");
    setDeepLink(null);
  };
  const openLogsFiltered = ({ app, level, hour }) => {
    setRoute("logs");
    setDeepLink({
      level,
      searchType: "Ctx Search",
      query: `Application:'${app}'`,
    });
    setTimeRange({ mode: "exact", exact: hour.toISOString(), label: `Hour ${hour.toISOString().slice(5,16)}` });
  };

  const titleByRoute = {
    dashboard: "Dashboard",
    logs: "Logs",
    ignore: "Ignore lists",
    settings: "Settings",
  };
  const crumbsByRoute = {
    dashboard: [env],
    logs: [env, timeRange.label],
    ignore: [env, subtab === "standing" ? "Standing" : "One-time"],
    settings: [],
  };

  return (
    <div className="ml-app">
      <Sidebar env={env} setEnv={setEnv} route={route}
               setRoute={(r) => { if (r === "logs") setDeepLink(null); setRoute(r); }}
               tz={tz} server={server}/>

      <main className="ml-app__main">
        <Topbar title={titleByRoute[route]} crumbs={crumbsByRoute[route]}
          right={<>
            <span className="ml-pill">env <strong style={{color:"var(--ml-fg)", marginLeft:4}}>{env}</strong></span>
            <span className="ml-pill">tz <strong style={{color:"var(--ml-fg)", marginLeft:4}}>{tz}</strong></span>
            <button className="ml-btn ml-btn--icon" title={t.dark ? "Light mode" : "Dark mode"}
                    onClick={()=>setTweak("dark", !t.dark)}>
              <Icon name={t.dark ? "sun" : "moon"}/>
            </button>
          </>}/>

        {route === "dashboard" && (
          <Dashboard env={env} tz={tz} openLogsFiltered={openLogsFiltered}/>
        )}
        {route === "logs" && (
          <LogsScreen tz={tz}
            timeLabel={timeRange.label}
            openTimeRange={() => setShowTimeDlg(true)}
            deepLink={deepLink}/>
        )}
        {route === "ignore" && (
          <IgnoreLists subtab={subtab} setSubtab={setSubtab}
            openAdd={(onAdd) => setAddDlg({ onAdd })}
            openEdit={(item, onSave) => setEditDlg({ item, onSave })}
            openDelete={(opts) => setConfirmDlg(opts)}/>
        )}
        {route === "settings" && (
          <Settings tz={tz} setTz={setTz} dark={t.dark} setDark={(v)=>setTweak("dark", v)}/>
        )}
      </main>

      {/* dialogs */}
      {showTimeDlg && (
        <TimeRangeDialog initial={timeRange}
          onClose={()=>setShowTimeDlg(false)}
          onApply={(tr) => { setTimeRange(tr); setShowTimeDlg(false); }}/>
      )}
      {addDlg && (
        <AddIgnoreDialog
          onClose={()=>setAddDlg(null)}
          onConfirm={(ev) => { addDlg.onAdd(ev); setAddDlg(null); }}/>
      )}
      {editDlg && (
        <EditOneTimeDialog item={editDlg.item}
          onClose={()=>setEditDlg(null)}
          onSave={(saved) => { editDlg.onSave(saved); setEditDlg(null); }}/>
      )}
      {confirmDlg && (
        <ConfirmDialog title={confirmDlg.title} body={confirmDlg.body} danger
          onClose={()=>setConfirmDlg(null)}
          onConfirm={() => { confirmDlg.onConfirm(); setConfirmDlg(null); }}/>
      )}

      {/* Tweaks panel */}
      <TweaksPanel>
        <TweakSection label="Theme"/>
        <TweakToggle label="Dark mode" value={t.dark} onChange={(v)=>setTweak("dark", v)}/>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
