/* components.jsx — shared bits used across screens */

const { useState, useEffect, useRef, useMemo, useCallback, Fragment } = React;

/* ---------- icons (inline SVG, small + crisp) ---------- */
const Icon = ({ name, size = 14, ...rest }) => {
  const p = ICONS[name] || ICONS.dot;
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none"
         stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"
         strokeLinejoin="round" aria-hidden="true" {...rest}>
      {p}
    </svg>
  );
};
const ICONS = {
  dashboard: <><rect x="2" y="2" width="5" height="6" rx="1"/><rect x="9" y="2" width="5" height="3" rx="1"/><rect x="9" y="7" width="5" height="7" rx="1"/><rect x="2" y="10" width="5" height="4" rx="1"/></>,
  logs:      <><path d="M3 2.5h7l3 3V13a.5.5 0 0 1-.5.5h-9A.5.5 0 0 1 3 13V3a.5.5 0 0 1 .5-.5z"/><path d="M9.5 2.5V6h3.5"/><path d="M5 8h6M5 10.5h6M5 5.5h2.5"/></>,
  ignore:    <><circle cx="8" cy="8" r="5.5"/><path d="M4.5 4.5l7 7"/></>,
  settings:  <><circle cx="8" cy="8" r="2"/><path d="M8 1.5v2M8 12.5v2M3.4 3.4l1.4 1.4M11.2 11.2l1.4 1.4M1.5 8h2M12.5 8h2M3.4 12.6l1.4-1.4M11.2 4.8l1.4-1.4"/></>,
  search:    <><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5l3 3"/></>,
  refresh:   <><path d="M13 8a5 5 0 1 1-1.7-3.8"/><path d="M13.5 2v3.5H10"/></>,
  filter:    <><path d="M2 3h12l-4.5 5.5V13l-3 1V8.5L2 3z"/></>,
  plus:      <><path d="M8 3v10M3 8h10"/></>,
  minus:     <><path d="M3 8h10"/></>,
  x:         <><path d="M3.5 3.5l9 9M12.5 3.5l-9 9"/></>,
  clock:     <><circle cx="8" cy="8" r="6"/><path d="M8 4.5V8l2.5 1.5"/></>,
  trash:     <><path d="M3 4h10M6 4V2.5h4V4M5 4l.7 9.5a1 1 0 0 0 1 .9h2.6a1 1 0 0 0 1-.9L11 4"/></>,
  pencil:    <><path d="M11 2.5l2.5 2.5L5 13.5H2.5V11L11 2.5z"/></>,
  warn:      <><path d="M8 2L1.5 13.5h13L8 2z"/><path d="M8 6.5v3.5"/><circle cx="8" cy="12" r="0.5" fill="currentColor"/></>,
  share:     <><circle cx="4" cy="8" r="1.5"/><circle cx="12" cy="4" r="1.5"/><circle cx="12" cy="12" r="1.5"/><path d="M5.3 7.3l5.4-2.6M5.3 8.7l5.4 2.6"/></>,
  sun:       <><circle cx="8" cy="8" r="3"/><path d="M8 1.5v1.5M8 13v1.5M2.5 8H4M12 8h1.5M3.8 3.8l1 1M11.2 11.2l1 1M3.8 12.2l1-1M11.2 4.8l1-1"/></>,
  moon:      <><path d="M13.5 9.5A6 6 0 1 1 6.5 2.5a5 5 0 0 0 7 7z"/></>,
  inbox:     <><path d="M2 9l2-5h8l2 5"/><path d="M2 9v4.5h12V9H10a2 2 0 0 1-4 0H2z"/></>,
  caret:     <><path d="M4 6l4 4 4-4"/></>,
};

/* ---------- severity bits ---------- */
const Ball = ({ lvl, size }) => (
  <span className={`ml-ball ${lvlClass(lvl)}`}
        style={size ? { width: size, height: size } : null}
        title={lvl} aria-label={lvl}/>
);
const LvlTag = ({ lvl, withBall = true }) => (
  <span className={`ml-lvltag ${lvlClass(lvl)}`}>
    {withBall && <span className="ml-ball" style={{width:6, height:6}}/>}
    {lvl}
  </span>
);

/* ---------- BarCell (count + bar, clickable) ---------- */
const BarCell = ({ value, max, kind, onClick }) => {
  const pct = max > 0 ? Math.max(2, Math.round((value / max) * 100)) : 0;
  const zero = value === 0;
  return (
    <div className={`ml-barcell ${zero ? "ml-barcell--zero" : ""}`}>
      <span className="ml-barcell__bar">
        {!zero && (
          <span className={`ml-barcell__fill ${kind}`} style={{ width: pct + "%" }}/>
        )}
      </span>
      <span className="ml-barcell__count" onClick={zero ? null : onClick} title={zero ? "0 events" : "Open in Logs"}>
        {value}
      </span>
    </div>
  );
};

/* ---------- KV pair list (context) ---------- */
const KVList = ({ items, clickable, onClickPair }) => (
  <span className="ml-kv">
    {items.map((p, i) => (
      <span key={i} className="ml-kv__pair"
            onClick={clickable ? () => onClickPair?.(p) : null}>
        <span className="ml-kv__k">{p.k}</span>
        <span className="ml-kv__sep">:</span>
        <span className="ml-kv__v">'{p.v}'</span>
      </span>
    ))}
  </span>
);

/* ---------- Formatters ---------- */
function fmtTime(d, tz = "UTC+0") {
  // ISO-ish, with micros stub
  if (tz === "Local") {
    const pad = (n,l=2) => String(n).padStart(l,"0");
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds()*1000,6).slice(0,6)}`;
  }
  // UTC
  const pad = (n,l=2) => String(n).padStart(l,"0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth()+1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}.${pad(d.getUTCMilliseconds()*1000,6).slice(0,6)}`;
}
function fmtHour(d, tz = "UTC+0") {
  const pad = (n) => String(n).padStart(2,"0");
  if (tz === "Local") {
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:00`;
  }
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth()+1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:00 UTC`;
}

/* ---------- Sidebar ---------- */
function Sidebar({ env, setEnv, route, setRoute, tz, server }) {
  return (
    <aside className="ml-side" role="navigation" aria-label="primary">
      <div className="ml-side__brand">
        <div className="ml-side__logo">L</div>
        <div className="ml-side__title">Logs</div>
      </div>

      <div className="ml-side__env">
        <div className="ml-side__label">Environment</div>
        <select className="ml-side__envselect" value={env} onChange={e => setEnv(e.target.value)}>
          {ENVS.map(n => <option key={n} value={n}>{n}</option>)}
        </select>
      </div>

      <div className="ml-side__tz">
        <span>TimeZone</span>
        <span style={{color:"var(--ml-side-fg)"}}>{tz}</span>
      </div>

      <nav className="ml-side__nav">
        {[
          { id: "dashboard", label: "Dashboard", icon: "dashboard" },
          { id: "logs", label: "Logs", icon: "logs" },
          { id: "ignore", label: "Ignore Lists", icon: "ignore" },
          { id: "settings", label: "Settings", icon: "settings" },
        ].map(item => (
          <div key={item.id}
               className={`ml-side__navitem ${route === item.id ? "is-active" : ""}`}
               onClick={() => setRoute(item.id)}>
            <span className="ico"><Icon name={item.icon}/></span>
            <span>{item.label}</span>
          </div>
        ))}
      </nav>

      <div className="ml-side__footer">
        <div className="row"><dt>Client ver</dt><dd>{server.client}</dd></div>
        <div className="row"><dt>Server ver</dt><dd>{server.server}</dd></div>
        <div className="row"><dt>GC</dt><dd>{server.gc}</dd></div>
        <div className="row"><dt>Status</dt>
          <dd><span className="ml-status"><span className="dot"/>connected</span></dd>
        </div>
      </div>
    </aside>
  );
}

/* ---------- Topbar ---------- */
function Topbar({ title, crumbs = [], right }) {
  return (
    <div className="ml-topbar">
      <div className="ml-topbar__title">
        <span>{title}</span>
        {crumbs.map((c,i) => (
          <span key={i} className="ml-topbar__crumb"> / {c}</span>
        ))}
      </div>
      <div className="ml-topbar__right">{right}</div>
    </div>
  );
}

/* ---------- States ---------- */
function LoadingRows({ rows = 8, cols = 5 }) {
  return (
    <tbody>
      {Array.from({length: rows}).map((_,r) => (
        <tr key={r}>
          {Array.from({length: cols}).map((__,c) => (
            <td key={c}><div className="ml-skel" style={{width: c === 0 ? 10 : c === 3 ? "80%" : "50%"}}/></td>
          ))}
        </tr>
      ))}
    </tbody>
  );
}
function EmptyState({ title, sub, icon = "inbox", action }) {
  return (
    <div className="ml-state">
      <div className="ml-state__icon"><Icon name={icon} size={18}/></div>
      <div className="ml-state__title">{title}</div>
      {sub && <div className="ml-state__sub">{sub}</div>}
      {action}
    </div>
  );
}
function ErrorState({ title, sub, onRetry }) {
  return (
    <div className="ml-state ml-state--error">
      <div className="ml-state__icon"><Icon name="warn" size={18}/></div>
      <div className="ml-state__title">{title}</div>
      {sub && <div className="ml-state__sub">{sub}</div>}
      {onRetry && <button className="ml-btn" onClick={onRetry} style={{marginTop:6}}>
        <Icon name="refresh"/> Retry
      </button>}
    </div>
  );
}

Object.assign(window, {
  Icon, Ball, LvlTag, BarCell, KVList,
  fmtTime, fmtHour,
  Sidebar, Topbar,
  LoadingRows, EmptyState, ErrorState,
});
