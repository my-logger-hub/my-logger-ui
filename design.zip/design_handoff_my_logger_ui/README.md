# Handoff: my-logger-ui — UI/UX редизайн

## Для кого этот документ
Этот пакет адресован **Claude Code**, работающему в репозитории `my-logger-ui` (Dioxus 0.7 / Rust / WASM web SPA). Ниже — подробная инструкция, как перенести готовый HTML-прототип на реальные Dioxus-компоненты, заменив инлайновые `style:`-строки на CSS-классы из `app.css`.

---

## 0. О файлах в пакете
В папке `prototype/` лежит **референсный HTML-прототип** — это **не код для копирования**. Это «эталон внешнего вида и поведения», по которому нужно собрать UI в Dioxus, используя уже существующие в проекте примитивы из:

- `dioxus-admin-ui-kit` — `InputValueComponent<T>`, `input_bool`, `select_enum_value` / `select_enum_value_opt`, `RenderTable<T>` с `TableItem`, `InputValue<T>` / `InputValueOpt<T>`, `EnumIterator`
- `dioxus-design-patterns` — диалоги, signals/state, конвенции компонентов

Если в `dioxus-admin-ui-kit` нет нужного примитива — **спроси у пользователя**, прежде чем изобретать новый. Дизайн намеренно построен так, чтобы выражаться через текущий вокабулярий китa.

**Fidelity:** Hi-fi. Все цвета, размеры, иконки и взаимодействия зафиксированы. Воспроизводить визуально точно.

---

## 1. Что НЕ менять (из ТЗ)
- Маршрутизация и base64 deep-link контракт (`LogPathDataModel`).
- Семантика уровней (Fatal/Error/Warning/Info/Debug). Оттенки можно подкручивать, **назначения — нет**.
- Google Charts как движок дашборда. Стилизуем вокруг, не заменяем.
- localStorage-ключи: `env`, `tz`, `level`, `time range`, `search type`, `search line`.

---

## 2. Архитектура CSS — ключевой шаг
Сейчас в коде разбросаны инлайновые `style:`-строки. Цель — заменить их на **именованную систему классов с префиксом `ml-*`**, токены `--ml-*`.

### 2.1. Перенос `styles.css` → `public/assets/app.css`
Файл `prototype/styles.css` нужно скопировать в `public/assets/app.css` (или добавить его содержимое к существующему). Он подключается уже сегодня. Не удаляй текущие Bootstrap/Velzon переменные (`--vz-*`) — наш слой накладывается сверху.

### 2.2. Темы (light/dark)
Тема задаётся атрибутом `data-theme` на `<html>`:
- `data-theme="light"` (по умолчанию) и `data-theme="dark"`
- Все токены — CSS-переменные внутри `:root,[data-theme="light"]` и `[data-theme="dark"]`
- В Dioxus переключение делается записью атрибута `data-theme` на `<html>` в эффекте, читающем `localStorage.theme`

### 2.3. Карта токенов (минимальная)
| Назначение | Переменная |
|---|---|
| Фон страницы | `--ml-bg-sub` |
| Поверхность карточки | `--ml-surface` |
| Тонкая граница | `--ml-border` |
| Жирная граница | `--ml-border-strong` |
| Основной текст | `--ml-fg` |
| Приглушённый текст | `--ml-fg-mute` |
| Акцент (фиолетовый, как у Datadog) | `--ml-accent` |
| Цвет ссылок | `--ml-link` |
| Боковая панель — фон | `--ml-side-bg` (`#282a42`, как сейчас) |
| Severity Fatal | `--sev-fatal` (`#0a0a0a`) |
| Severity Error | `--sev-error` (`#dc2626`) |
| Severity Warning | `--sev-warning` (`#ea8a0c`) |
| Severity Info | `--sev-info` (`#15803d`) |
| Severity Debug | `--sev-debug` (`#6b7280`) |
| Layout | `--panel-width: 200px`, `--topbar-h: 44px` |
| Высота строки/инпута/кнопки | `--ml-row-h`, `--ml-input-h`, `--ml-btn-h` (26px — max-density) |

Полный список — в самом `styles.css`, секции 1 и 9.

### 2.4. Типографика
- Sans (UI): **Inter**, fallback на системные
- Mono (логи, таймстемпы, контекст): **JetBrains Mono**
- Базовый размер UI: 12px (`--ml-fs-sm`); таблицы тоже 12px

Подключение шрифтов — в `<head>` основного `index.html`:
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
```

---

## 3. Карта файлов: HTML-прототип → Dioxus

| Прототип (компонент) | Файл в `my-logger-ui` |
|---|---|
| `Sidebar` (`components.jsx`) | `src/views/left_panel.rs` + `src/views/envs_selector.rs` |
| `Topbar` | новый `src/views/top_bar.rs` (см. §4.2) |
| `Dashboard` → `ChartCard` (`screens.jsx`) | `src/views/dashboard/hourly_graph.rs` |
| `Dashboard` → `TopAppsCard` | `src/views/dashboard/top_apps_with_errors.rs` |
| `LogsScreen` → search bar | `src/views/logs/render_logs_panel.rs` |
| `LogsScreen` → результирующая таблица | `src/views/logs/render_logs.rs` |
| `LogsScreen` → level select | `src/views/logs/select_log_level.rs` |
| `LogsScreen` → `Ball` | `src/views/logs/render_log_ball.rs` |
| `LogsScreen` → insights popover | новый `src/views/logs/insights_popover.rs` (заменяет скрытый `#insights-panel`) |
| `TimeRangeDialog` | `src/views/logs/edit_time_range_dialog.rs` |
| `IgnoreLists` tabs | `src/views/ignore_lists/render_tabs.rs` |
| `IgnoreLists` (standing) | `src/views/ignore_lists/render_ignore_list.rs` |
| `IgnoreLists` (one-time) | `src/views/ignore_lists/render_one_time_ignore_list.rs` |
| `AddIgnoreDialog` (+ confirmation) | существующий + `render_add_ignore_event_confirmation.rs` |
| `EditOneTimeDialog` | `src/views/ignore_lists/edit_one_time_ignore_event.rs` |
| `Modal` shell | `src/views/dialog_template.rs` |
| `Settings` | `src/views/settings/render_settings.rs` |

---

## 4. Общая обвязка приложения

### 4.1. Layout shell (`src/main.rs`, `ActiveApp`)
```html
<div class="ml-app">
  <aside class="ml-side"> ... </aside>
  <main class="ml-app__main">
    <div class="ml-topbar"> ... </div>
    <!-- активный view -->
  </main>
  <!-- слой модалок RenderDialog -->
</div>
```
- `.ml-app` — flex row, минимум 100vh
- `.ml-side` — `position: sticky; top: 0; height: 100vh; width: var(--panel-width)`
- Главная панель прокручивается сама — `overflow: auto` НЕ нужен на `.ml-app__main`, прокручивает body

### 4.2. Topbar (новый компонент)
Шапка для каждой страницы:
```html
<div class="ml-topbar">
  <div class="ml-topbar__title">Logs <span class="ml-topbar__crumb"> / prod-eu</span></div>
  <div class="ml-topbar__right">
    <span class="ml-pill">env <strong>prod-eu</strong></span>
    <span class="ml-pill">tz <strong>UTC+0</strong></span>
    <button class="ml-btn ml-btn--icon" aria-label="Toggle theme"><svg>...</svg></button>
  </div>
</div>
```
Это снимает старую боль — search panel перестаёт быть `position: fixed`. У нас:
- `.ml-topbar` — `position: sticky; top: 0; z-index: 10`
- `.ml-logbar` (см. Logs) — `position: sticky; top: var(--topbar-h); z-index: 9`

Прокручивается основной поток, обе плашки прилипают сверху. Никаких хаков с `margin-top: 61px`.

---

## 5. Sidebar — `src/views/left_panel.rs`

### Структура
1. **Brand** (`.ml-side__brand`): логотип-квадрат 22×22 + текст "Logs"
2. **Env selector** (`.ml-side__env`): label "ENVIRONMENT" + `<select>` с классом `.ml-side__envselect`
   - На смену env: сбросить state, навигировать на `/dashboard/:env`
   - localStorage key — `env`
3. **TimeZone indicator** (`.ml-side__tz`): two-column row — слева label, справа значение
4. **Nav** (`.ml-side__nav`): 4 пункта (Dashboard, Logs, Ignore Lists, Settings). Активный — `.ml-side__navitem.is-active`
   - Каждый пункт: иконка 14px (см. §11) + текст
   - На клик по "Logs" — очистить persisted time range / search line / log level (как сейчас)
5. **Footer** (`.ml-side__footer`): `dt`/`dd` пары — Client ver, Server ver, GC, Status

### Иконки (используй inline SVG, не библиотеку)
Прототип содержит набор путей в `components.jsx` → `ICONS`. Перенеси их как отдельные `rsx!` функции:
- `icon_dashboard`, `icon_logs`, `icon_ignore`, `icon_settings`, `icon_clock`, `icon_refresh`, `icon_search`, `icon_plus`, `icon_x`, `icon_trash`, `icon_pencil`, `icon_warn`, `icon_share`, `icon_sun`, `icon_moon`, `icon_filter`, `icon_caret`, `icon_inbox`

---

## 6. Dashboard

### 6.1. Hourly chart (`hourly_graph.rs`)
**Google Charts остаётся.** Подкручиваем оформление контейнера:
- Обёртка: `<section class="ml-card">` с `<header class="ml-card__hd">` + `<div class="ml-chart__legend">` + `<div class="ml-chart">` под чарт
- В легенде: 5 swatches цветов (черный, красный, оранжевый, тёмно-зелёный, серый) + справа "peak N/h"
- Заголовок: `Errors statistics per hour`, sub справа: `Environment: prod-eu · Window: last 24h · UTC+0`
- Параметры Google Charts: серии в порядке `FatalError, Error, Warning, Info, Debug`, цвета — точные хексы из токенов severity. Backgroundcolor чарта — `transparent`, гридлайны — `var(--ml-border-soft)`
- Высота — 360px

### 6.2. Top apps with errors (`top_apps_with_errors.rs`)
- `<section class="ml-card">`, заголовок "Top apps with errors", subtitle "grouped by hour, sorted by severity · counts deep-link to filtered Logs"
- Таблица `.ml-table` с колонками: Application | Errors (right) | Fatal errors (right) | Warnings (right)
- **Группы по часам**: каждый час = отдельный `<tbody>`, начинается строкой `<tr class="ml-table__group">` с `colspan=4`:
  - "Hour 2026-05-28 14:00 UTC · 4 apps · 312 events"
  - Внутри — отсортированные по severity строки приложений
- **BarCell** (числовая ячейка):
  ```html
  <div class="ml-barcell">
    <span class="ml-barcell__bar">
      <span class="ml-barcell__fill lvl-error" style="width: 73%"></span>
    </span>
    <a class="ml-barcell__count" href="/logs/...">42</a>
  </div>
  ```
  - `lvl-error` для Errors, `lvl-fatal` для Fatal, `lvl-warning` для Warnings
  - Ширина бара = `value / max_in_period * 100%`, минимум 2%
  - Ноль: класс `.ml-barcell--zero` — серый, не кликабельный, без бара
- Клик по счётчику — deep-link на `/logs/<base64>` с `Application:'<app>'`, level=Error|FatalError|Warning, time=Exact hour

---

## 7. Logs view — самый большой экран

### 7.1. Search bar (`render_logs_panel.rs`)
```html
<div class="ml-logbar">
  <div class="ml-logbar__group">
    <span class="ml-field__label">Level</span>
    <select class="ml-select ml-select--lvl lvl-error">All / Debug / Info / Warning / Error / FatalError</select>
  </div>
  <div class="ml-logbar__group">
    <span class="ml-field__label">Time</span>
    <button class="ml-btn"><svg icon-clock/> Last 6h</button>
  </div>
  <div class="ml-logbar__group">
    <span class="ml-field__label">Type</span>
    <select class="ml-select">Ctx Search / Text Search</select>
  </div>
  <div class="ml-logbar__search">
    <span class="ico"><svg icon-search/></span>
    <input class="ml-input" placeholder="Application='MyApp' and Version='3.14.2'"/>
    <span class="ml-logbar__searchhint">@ for fields</span>
    <!-- insights popover вставляется сюда при фокусе -->
  </div>
  <button class="ml-btn ml-btn--icon" title="Refresh"><svg icon-refresh/></button>
  <button class="ml-btn ml-btn--icon" title="Share"><svg icon-share/></button>
</div>
```

Важно:
- Level `<select>` принимает класс `lvl-<level>`, который меняет цвет текста на цвет severity (`.ml-select--lvl.lvl-error` и т.д.)
- Время рендерится как кнопка с лейблом по режиму: `Last 6h`, `Hour 05-28 14:00`, `2026-05-28 12:00 → 2026-05-28 18:00`. Клик → открыть TimeRangeDialog
- Placeholder зависит от типа: для Ctx — пример с ключами, для Text — `Just a text`
- Хинт справа в инпуте (`.ml-logbar__searchhint`) — `@ for fields` в Ctx-режиме, `↵ search` в Text-режиме
- На Enter — триггерим поиск (snapshot URL обновляется)
- Кнопка Refresh = `Link` на base64 deep-link текущего search-state (как сейчас)

### 7.2. Insights popover (АКТУАЛЬНОЕ изменение)
Заменяем спрятанный `#insights-panel` на нормальный автокомплит.

Триггеры открытия:
- Фокус инпута + пустой текущий токен (после ` and ` или в самом начале)
- Нажатие `@`
- Hotkey `Ctrl+Space`

Структура:
```html
<div class="ml-insights">
  <div class="ml-insights__hd">
    <svg icon-filter/> Context keys for this env
    <span style="margin-left:auto">10 of 10</span>
  </div>
  <div class="ml-insights__list">
    <div class="ml-insights__item is-active">
      <span class="ml-insights__k">Application</span>
      <span class="ml-insights__sample">checkout-api, payments-svc, …</span>
      <span class="ml-insights__count">12</span>
    </div>
    <!-- ... -->
  </div>
  <div class="ml-insights__ft">
    <span><kbd class="ml-insights__kbd">↑↓</kbd> navigate · <kbd>↵</kbd> insert · <kbd>esc</kbd> close</span>
    <span>Ctx Search mode</span>
  </div>
</div>
```

Поведение:
- Источник данных — известные ключи контекста для текущего env (как у тебя уже грузится per-env)
- При выборе/Enter: вставляет в инпут `<Key>:'` и оставляет курсор внутри кавычек
- Фильтрация по тому, что юзер набрал в текущем токене (последний после ` and `)
- ↑/↓ — навигация по списку; Esc — закрыть

### 7.3. Результирующая таблица (`render_logs.rs`)
```html
<div class="ml-card ml-card--flat">
  <table class="ml-table ml-table--logs is-clickable"> <!-- is-clickable только в Ctx mode -->
    <thead>
      <tr>
        <th class="col--ball"></th>
        <th class="col--time">Time</th>
        <th class="col--proc">Process</th>
        <th>Message</th>
        <th>Context</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td class="col--ball"><span class="ml-ball lvl-error"></span></td>
        <td class="col--time">2026-05-28 14:23:45.123456</td>
        <td class="col--proc">checkout-api/p-a17</td>
        <td class="col--msg">Database connection refused</td>
        <td>
          <span class="ml-kv">
            <span class="ml-kv__pair">
              <span class="ml-kv__k">Application</span><span class="ml-kv__sep">:</span><span class="ml-kv__v">'checkout-api'</span>
            </span>
            <!-- ещё пары -->
          </span>
        </td>
      </tr>
    </tbody>
  </table>
</div>
```

- `thead th` — sticky сверху (`position: sticky; top: 0`)
- `.col--ball` 16px, `.col--time` 132px, `.col--proc` 140px mono — фиксированы
- `Time` и `Process` — mono шрифт (через свойство в `.ml-table .col--time`/`.col--proc`)
- `Message` — mono, перенос по словам (`word-break: break-word`)
- `Context` — `.ml-kv` с парами `.ml-kv__pair`
- **Click-to-filter (Ctx Search ТОЛЬКО)**:
  - На таблицу добавляем класс `is-clickable`
  - `.is-clickable .ml-kv__pair:hover` — лиловая подсветка + бордер
  - `.is-clickable .col--proc:hover` — лиловый цвет + underline
  - На клик: append к search line `… and Key:'Value'` (или `Process:'<proc>'`)
  - В Text Search режиме — НЕТ класса `is-clickable`, курсор обычный, hover-эффектов нет
- Лимит высоты: `max-height: calc(100vh - 160px); overflow: auto;` — не растягиваем body

### 7.4. Шапка с количеством
Над таблицей — тонкая строка:
```html
<div class="ml-hint">
  <strong>1,248</strong> events · Last 6h · Click any context key, value or process to add as filter.
</div>
```

### 7.5. Time Range dialog (`edit_time_range_dialog.rs`)
- Modal через `.ml-modal-pad` + `.ml-modal`
- Заголовок: `Edit time range`
- Body: form-grid с одной верхней строкой "Mode" → segmented control:
  ```html
  <div class="ml-seg">
    <button class="ml-seg__btn is-active">Hours ago</button>
    <button class="ml-seg__btn">Date range</button>
    <button class="ml-seg__btn">Exact hour</button>
  </div>
  ```
- Под ним — поля по режиму:
  - **Hours ago**: один `<input type=number>` ширина 90px + хинт справа
  - **Date range**: два `<input type=datetime-local>` (From / To) + хинт про timezone
  - **Exact hour**: один `<input type=datetime-local>`
- Footer: Cancel (`.ml-btn`) + Apply (`.ml-btn.is-primary`)
- На Apply — закрыть, сохранить, перевыполнить запрос

---

## 8. Ignore Lists

### 8.1. Tabs
```html
<div class="ml-tabs">
  <div class="ml-tabs__tab is-active">Ignore list <span class="count">5</span></div>
  <div class="ml-tabs__tab">One time ignore <span class="count">3</span></div>
</div>
```
- Активный таб — нижняя 2px линия акцентного цвета
- Bage с count — `.count` (chip с background `--ml-surface-2`)
- При `/ignoreLists/ignore-single-time` сразу активен второй таб

### 8.2. Standing list (`render_ignore_list.rs`)
Карточка `.ml-card.ml-card--flat`:
- Header c заголовком "Standing ignore rules", subtitle и **кнопкой Add** справа: `<button class="ml-btn is-primary"><svg icon-plus/> Add ignore event</button>`
- Таблица: columns `(ball) | Level | Application | Marker | Actions`
- Level: `<span class="ml-lvltag lvl-warning"><span class="ml-ball"></span>Warning</span>`
- Application + Marker — mono
- Actions: две кнопки `.ml-btn.is-ghost` с иконками pencil и trash; trash → ConfirmDialog (см. §10.2)

### 8.3. One-time list (`render_one_time_ignore_list.rs`)
- Columns: Levels | Message match | Context match | Skip (right) | Minutes (right) | Actions
- "Levels" — inline-стопка `.ml-lvltag` для каждого выбранного уровня (с маленьким ball'ом)
- "Context match" — `.ml-kv` (тот же компонент). Если пустой — `—` в `--ml-fg-faint`
- Skip / Minutes — mono, right-align
- Actions: Edit (карандаш) → EditOneTimeDialog; Delete (мусорка) → ConfirmDialog

### 8.4. EditOneTimeDialog (`edit_one_time_ignore_event.rs`)
Wide modal (`.ml-modal--wide`). Form-grid с двумя колонками (label 140px + content).

Поля и валидация (как в ТЗ):
- **Levels** (multi-select): чипы `.ml-lvlchk` с маленьким ball'ом — каждый кликается, активный получает `.is-checked`. Должен быть выбран ≥1 → иначе ошибка "Select at least one level."
- **Message match** (text): `.ml-input.ml-input--mono` — не пустой → иначе `.is-invalid` border + `.ml-field__error`
- **Skip amount** (int, > 0): `.ml-input` ширина 96 + хинт справа
- **Minutes to wait** (int, > 0): то же
- **Context match** (KV builder):
  - Уже добавленные пары — чипы `.ml-kvedit__chip` с кнопкой ×
  - Внизу строка `.ml-kvedit__add` — три колонки: ключ (с `<datalist>` известных ключей) + значение + кнопка Add
  - Enter в поле "value" = добавить пару
- Кнопка "Save" имеет `.is-disabled` пока невалидно — `pointer-events: none`

В Dioxus — используй `InputValue<T>` и `input_bool` из кита, они уже умеют красную рамку при невалиде. Чип уровня — кастомный, но базируется на `select_enum_value`.

### 8.5. Add ignore event + confirmation
Двухшаговый flow в **одном** диалоге:
- Шаг "edit": Level select (с `.ml-select--lvl`), Application input (mono, placeholder `* (all apps)`), Marker textarea (mono, обязательная)
- Кнопка "Next" → переключает на step "confirm"
- Шаг "confirm": блок `.ml-modal__warn` с предупреждением + read-only сводка (Level tag, Application pill, Marker block). Кнопки: "Back" / "Add to ignore list"

---

## 9. Settings (`render_settings.rs`)
- Карточка `.ml-card.ml-settings`
- Header с title "Settings" и sub "Local to this browser — persisted in localStorage"
- Тело — последовательность `.ml-settings__row`:
  - `<div class="ml-settings__lbl"><strong>Time zone</strong><span>Drives every timestamp rendered…</span></div>`
  - справа — контрол
- Сейчас: Time Zone (`<select>` с двумя опциями), Theme (segmented Light/Dark), Density (segmented), Auto-refresh (`<select>`)
- Паттерн расширяемый — новые настройки добавляются как ещё один `.ml-settings__row`

---

## 10. Cross-cutting

### 10.1. Severity palette (canonical)
| Level | Text/dot color | Soft background |
|---|---|---|
| FatalError | `var(--sev-fatal)` `#0a0a0a` | `var(--sev-fatal-bg)` `#ececec` |
| Error | `var(--sev-error)` `#dc2626` | `var(--sev-error-bg)` `#fde8e8` |
| Warning | `var(--sev-warning)` `#ea8a0c` | `var(--sev-warning-bg)` `#fdf0d8` |
| Info | `var(--sev-info)` `#15803d` | `var(--sev-info-bg)` `#dff3e6` |
| Debug | `var(--sev-debug)` `#6b7280` | `var(--sev-debug-bg)` `#eceef1` |
| All (фильтр) | `var(--sev-all)` | — |

Эти токены применяются везде: `ml-ball.lvl-*`, `ml-lvltag.lvl-*`, `ml-select--lvl.lvl-*`, `ml-barcell__fill.lvl-*`, серии Google Charts. **Один источник истины.**

В dark-режиме оттенки чуть подняты для контраста, см. блок `[data-theme="dark"]` в `styles.css`. Для Fatal в тёмной теме добавлен outline вокруг ball'a, чтобы он не сливался с фоном.

### 10.2. Modal/Dialog система
Единый shell — `src/views/dialog_template.rs`:
```html
<div class="ml-modal-pad"> <!-- backdrop, клик мимо закрывает -->
  <div class="ml-modal"> <!-- или .ml-modal.ml-modal--wide для EditOneTime -->
    <div class="ml-modal__hd">
      <div class="ml-modal__title">…</div>
      <button class="ml-modal__close"><svg icon-x/></button>
    </div>
    <div class="ml-modal__bd">…</div>
    <div class="ml-modal__ft">
      <button class="ml-btn">Cancel</button>
      <button class="ml-btn is-primary">OK</button>
    </div>
  </div>
</div>
```
- `Esc` закрывает
- Клик по `.ml-modal-pad` (но не по `.ml-modal`) закрывает
- Анимация: backdrop fade 120ms, modal pop 140ms (`@keyframes ml-fade` / `ml-pop` уже в CSS)
- Для destructive flows используем `.ml-modal__warn` блок внутри body (жёлтая плашка с иконкой warn)
- ConfirmDialog для удалений: кнопка confirm имеет `.ml-btn.is-danger` (красная рамка, прозрачный фон)

### 10.3. Loading / empty / error
**Loading skeleton**:
```html
<tbody>
  <tr><td><div class="ml-skel" style="width:50%"></div></td>…</tr>
</tbody>
```
- `.ml-skel` — анимированный shimmer (см. `@keyframes ml-shimmer`)
- Для inline loaders — `.ml-spinner` (14px кружок)

**Empty state**:
```html
<div class="ml-state">
  <div class="ml-state__icon"><svg icon-inbox/></div>
  <div class="ml-state__title">No matching events</div>
  <div class="ml-state__sub">Try a wider time range, different level, or remove search terms.</div>
</div>
```

**Error state** — то же, плюс класс `.ml-state--error`:
```html
<div class="ml-state ml-state--error">
  <div class="ml-state__icon"><svg icon-warn/></div>
  <div class="ml-state__title">Failed to load logs</div>
  <div class="ml-state__sub">Server returned 503 after 3 retries.</div>
  <button class="ml-btn"><svg icon-refresh/> Retry</button>
</div>
```

Замени все нынешние `"Loading..."` / `"Error loading data: <err>"` на эти паттерны. Под каждый view:
- Dashboard chart — skeleton с пустым `.ml-chart` 360px + спиннер по центру
- Top apps — skeleton-строки в табличной форме (8 строк × 4 колонки)
- Logs — skeleton-строки (12 × 5)
- Ignore lists — skeleton-строки (5 × 4/5)
- Server info (sidebar footer) — точки `…` пока не ответил

### 10.4. Responsive
Sidebar коллапсируется в icon-rail на узких viewport'ах (≤880px):
- Меняем `--panel-width: 48px`
- Скрываем текст брэнда, env-селектор, TZ row, footer, лейблы пунктов меню
- Иконки остаются центрированными
- `.ml-logbar` оборачивается на следующую строку (`flex-wrap: wrap`)

Это уже сделано через `@media (max-width: 880px)` в самом конце `styles.css`. Десктоп всё ещё первичный таргет.

### 10.5. Deep links
URL контракт **не трогаем**:
- `/logs/<base64(LogPathDataModel)>` — поле LogPathDataModel включает search type, search string, level, time range
- Кнопка Refresh — `Link` на base64-сериализованный текущий state
- Click по числу в Top apps → формирует deep-link с `Application:'<app>'`, level, time=Exact hour

Визуально ничего нового — просто проследи, что `.ml-btn.ml-btn--icon` (Refresh) обёрнут в `Link`, а не `button`.

---

## 11. Иконки
Используй inline SVG (`viewBox="0 0 16 16"`, stroke `currentColor`, stroke-width 1.5). Все 17 иконок есть в `prototype/components.jsx` → константа `ICONS`. Перенеси один-в-один в Dioxus как функции, возвращающие `Element`.

Не подключай дополнительные icon-библиотеки. Прототип специально использовал минимальный inline-набор.

---

## 12. Что проверить вручную после реализации

1. **Темы** — переключаются через атрибут `data-theme` на `<html>`. Все цвета, включая severity, корректны в обеих темах. Fatal-ball виден на тёмном фоне (outline).
2. **Sidebar** — env-select меняет route и сбрасывает state; активный пункт меню подсвечен; footer показывает Client/Server/GC/Status.
3. **Dashboard** — Google Charts использует токены, легенда сверху, "peak N/h" справа. Top apps группируется по часам, BarCell кликается, deep-link в Logs работает.
4. **Logs** — search bar sticky под topbar'ом, без `margin-top: 61px` хака. Level select раскрашивается по уровню. В Ctx mode hover на context-pair/process даёт лиловую подсветку; клик добавляет ` and Key:'Value'`. В Text mode — никакого hover, курсор обычный.
5. **Insights popover** — открывается на `@`/фокусе пустого токена, навигация ↑↓, Enter вставляет `Key:'`. Esc закрывает.
6. **Time Range dialog** — segmented control переключает 3 режима, каждый показывает свои инпуты, Apply сохраняет.
7. **Ignore Lists** — оба таба, add-flow с confirmation, edit one-time с валидацией (все 4 правила), KV-builder работает.
8. **Settings** — переключение TZ перерисовывает таймстемпы во всём приложении; theme toggle переключает атрибут на `<html>`.
9. **States** — отключи бэкенд, убедись что каждый view показывает proper error state с Retry, а не bare "Error loading data: …".

---

## 13. Файлы прототипа
- `prototype/my-logger-ui.html` — точка входа
- `prototype/styles.css` — **переносится в `public/assets/app.css`**
- `prototype/components.jsx` — Sidebar, Topbar, Ball, LvlTag, BarCell, KVList, иконки, formatters, состояния
- `prototype/screens.jsx` — Dashboard, LogsScreen, IgnoreLists, Settings
- `prototype/dialogs.jsx` — Modal shell + 4 диалога
- `prototype/mock-data.jsx` — синтетические данные (для рендера прототипа, не для копирования)
- `prototype/app.jsx` — корневой компонент с роутингом-стейтом и диалогами
- `prototype/tweaks-panel.jsx` — внутренний инструмент для прототипа, в продакшен не идёт

**Открой `prototype/my-logger-ui.html` локально** — это эталон, по которому сверяешь визуал и поведение. Все экраны и диалоги интерактивны.

---

## 14. Если что-то непонятно
- Размеры/цвета/токены, не указанные здесь — смотри `prototype/styles.css`, секции 1 и 9
- Поведение взаимодействий — открой соответствующий экран в прототипе, проинспектируй DOM
- Маппинг на компоненты `dioxus-admin-ui-kit`, если не очевиден — спроси у пользователя, **не изобретай новые примитивы**
